import java.util.*;

public abstract class GeneCalc {
  private String fatherName;
  private String motherName;
  private ArrayList<String> fatherGenes = new ArrayList<>();
  private ArrayList<String> motherGenes = new ArrayList<>();
  private ArrayList<String> possibleChildAllelesFather1 = new ArrayList<>();
  private ArrayList<String> possibleChildAllelesFather2 = new ArrayList<>();
  private ArrayList<String> possibleChildAllelesMother1 = new ArrayList<>();
  private ArrayList<String> possibleChildAllelesMother2 = new ArrayList<>();
  private ArrayList<String> allChildGenotypes = new ArrayList<>();
  private ArrayList<String> possibleChildGenotypes = new ArrayList<>();
  private ArrayList<Integer> genotypeRatios = new ArrayList<>();
  private int totalChildGenotypes;
  private int count;
  private int sum;

  GeneCalc(ArrayList<String> fatherGenes, ArrayList<String> motherGenes) {
    fatherName = "Bob";
    motherName = "Sarah";
    this.fatherGenes = fatherGenes;
    this.motherGenes = motherGenes;
  }

  public void splitGenes() {
    // Maybe split genes into individual alleles. Mix and match alleles of father
    // with all possible combos of mother, and add all possibilities to an array.
    // loop through array to find total genes + get total count of all possible gene
    // combos.
    for (int x = 0; x < fatherGenes.size(); x++) {

      for (int y = 1; y < fatherGenes.size(); y++) {
        try {
          possibleChildAllelesFather1.get(x);
          possibleChildAllelesFather1.set(y, possibleChildAllelesFather1.get(x) + "" + possibleChildAllelesFather1.get(y));
        }
        catch (IndexOutOfBoundsException e) {
          possibleChildAllelesFather1.add(fatherGenes.get(x).charAt(0) + "");
        }
      }

      for (int z = 0; z < fatherGenes.size(); z++) {
        possibleChildAllelesFather2.add(fatherGenes.get(x).charAt(1) + "");
      }

      for (int a = 0; a < motherGenes.size(); a++) {
        possibleChildAllelesMother1.add(motherGenes.get(x).charAt(0) + "");
      }

      for (int b = 0; b < motherGenes.size(); b++) {
        possibleChildAllelesMother2.add(motherGenes.get(x).charAt(1) + "");
      }
      

    }
    /* the code within the comment is just for checking
    for (int x = 0; x < fatherGenes.size(); x++) {
      System.out.print(possibleChildAllelesFather1.get(x));
    }

    System.out.println("\n");

    for (int x = 0; x < fatherGenes.size(); x++) {
      System.out.print(possibleChildAllelesFather2.get(x));
    }

     System.out.println("\n");

    for (int x = 0; x < fatherGenes.size(); x++) {
      System.out.print(possibleChildAllelesMother1.get(x));
    }

     System.out.println("\n");

    for (int x = 0; x < fatherGenes.size(); x++) {
      System.out.print(possibleChildAllelesMother2.get(x));
    }

     System.out.println("\n");
    */
  }

  public void pairGenes() {
    
    for (int x = 0; x < possibleChildAllelesFather1.size(); x++) {
      for (int y = 0; y < possibleChildAllelesFather1.size(); y++) {
        allChildGenotypes.add(possibleChildAllelesFather1.get(x) + "" + possibleChildAllelesFather2.get(x));
      }
    }

    for (int x = 0; x < possibleChildAllelesFather1.size(); x++) {
      for (int y = 0; y < possibleChildAllelesFather1.size(); y++) {
        allChildGenotypes.add(possibleChildAllelesFather1.get(x) + "" + possibleChildAllelesMother2.get(x));
      }
    }

    for (int x = 0; x < possibleChildAllelesFather1.size(); x++) {
      for (int y = 0; y < possibleChildAllelesFather1.size(); y++) {
        allChildGenotypes.add(possibleChildAllelesFather2.get(x) + "" + possibleChildAllelesMother1.get(x));
      }
    }

    for (int x = 0; x < possibleChildAllelesFather1.size(); x++) {
      for (int y = 0; y < possibleChildAllelesFather1.size(); y++) {
        allChildGenotypes.add(possibleChildAllelesFather2.get(x) + "" + possibleChildAllelesMother2.get(x));
      }
    }
  }

  public void getPossibleChildGenotypes() {
    for (int x = 0; x < allChildGenotypes.size(); x++) {

      for (int y = 0; y < allChildGenotypes.size(); y++) {
        try {
          if (allChildGenotypes.get(x).equals(possibleChildGenotypes.get(y))) {
          // nothing
          }
          else {
          possibleChildGenotypes.add(allChildGenotypes.get(x));
          }
          
        }
        catch (IndexOutOfBoundsException e) {
          //nothing
        }
        

      }
    }
  }

  public void genotypeRatioCalc() {
    for (int x = 0; x < allChildGenotypes.size(); x++) {

      for (int y = 0; y < allChildGenotypes.size(); y++) {
        try {
          if (allChildGenotypes.get(x).equals(possibleChildGenotypes.get(y))) {
            try {
              count = genotypeRatios.get(x);
              genotypeRatios.set(x, count + 1);
            } 
            catch (IndexOutOfBoundsException e) {
              count = 0;
              genotypeRatios.set(x, count + 1);
            }
          }
        }
        catch (IndexOutOfBoundsException e) {
          //nothing
        }
      }

      totalChildGenotypes = x;
    }

    System.out.println(
        "There are " + possibleChildGenotypes.size() + " possible genotypes for the child\n the ratio is as follows: ");
    for (int x = 0; x < possibleChildGenotypes.size(); x++) {
      System.out.println(possibleChildGenotypes.get(x) + ": " + genotypeRatios.get(x));
    }
  }

  public abstract void phenotypeRatioCalc();
}