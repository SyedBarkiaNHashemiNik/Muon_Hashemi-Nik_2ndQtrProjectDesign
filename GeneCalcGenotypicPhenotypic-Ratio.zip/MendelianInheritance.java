import java.util.*;

public class MendelianInheritance extends GeneCalc{
  public MendelianInheritance(ArrayList<String> x, ArrayList<String> y) {
    super(x, y);
  }

  public void phenotypeRatioCalc() {
    System.out.println("The code for phenotypic ratio has yet to be made");
  }
}