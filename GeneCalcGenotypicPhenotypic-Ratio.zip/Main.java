import java.util.*;
import javax.swing.*;
import java.awt.*;

class Main {
  public static void main(String[] args) {
    ArrayList<String> fatherGenes = new ArrayList<String>();
    ArrayList<String> motherGenes = new ArrayList<String>();
    String allele;
    String geneChoice;
    int geneNumber = 0;
    Scanner myInput = new Scanner(System.in);

    JFrame window = new JFrame();
    window.setTitle("Input Menu");
    window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    window.setSize(800, 800);
    window.setLayout(new FlowLayout());
    
    JLabel windowLabel = new JLabel();
    window.add(windowLabel);
    windowLabel.setText("Testing Testing");

    JButton windowButton = new JButton("Next");
    windowButton.setSize(100, 100);
    window.add(windowButton);

    JTextField windowText = new JTextField(6);
    JPasswordField windowPassword = new JPasswordField(6);
    window.add(windowText);
    window.add(windowPassword);

    window.setVisible(true);

    
    /*
    System.out.println("Enter the genetic inheritance of choice. Mendelian, Incomplete or Codominant");
    geneChoice = myInput.nextLine();
    
    try {
      System.out.println("How many genes would you like to enter?");
      geneNumber = myInput.nextInt();
    }
    catch (InputMismatchException e) {
      System.out.println("Must input integers.");
    }
    catch (Exception e) {
      System.out.println("Invalid input");
    }
 

    for (int x = 0; x < geneNumber; x++) {
      try {
        System.out.println("Enter the alleles of the father (AA, Aa, aa)");
        allele = myInput.next();
        fatherGenes.add(allele);
        if (fatherGenes.get(x).length() != 2) {
          throw new WrongLengthException("You must always input two alleles");
        }
      }
      catch (WrongLengthException e) {
        fatherGenes.clear();
        e.getMessage();
      }
      catch (Exception e) {
        System.out.println("Invalid input");
      }
      
      
      
    }

    System.out.println("\n");
    
    if (fatherGenes.get(0).length() == 2) {
      for (int x = 0; x < geneNumber; x++) {
        try {
          System.out.println("Enter the alleles of the mother (AA, Aa, aa)");
          allele = myInput.next();
          motherGenes.add(allele);
          if (motherGenes.get(x).length() != 2) {
            throw new WrongLengthException("You must always input two alleles");
          }
        }
        catch (WrongLengthException e) {
          e.getMessage();
        }
        catch (Exception e) {
          System.out.println("Invalid input");
        }
        
      }
    }

    switch (geneChoice) {
      case "Mendelian":
        MendelianInheritance x = new MendelianInheritance(fatherGenes, motherGenes);
        x.splitGenes();
        x.pairGenes();
        x.getPossibleChildGenotypes();
        x.genotypeRatioCalc();
        x.phenotypeRatioCalc();
        break;
      case "Incomplete":
        IncompleteDominance y = new IncompleteDominance(fatherGenes, motherGenes);
        y.splitGenes();
        y.pairGenes();
        y.getPossibleChildGenotypes();
        y.genotypeRatioCalc();
        y.phenotypeRatioCalc();
        break;
      case "Codominant":
        Codominance z = new Codominance(fatherGenes, motherGenes);
        z.splitGenes();
        z.pairGenes();
        z.getPossibleChildGenotypes();
        z.genotypeRatioCalc();
        z.phenotypeRatioCalc();
        break;
      default:
        System.out.println("Invalid");
    }
    */
  }
}