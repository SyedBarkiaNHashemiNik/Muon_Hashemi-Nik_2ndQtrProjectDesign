import java.util.*;

public class IncompleteDominance extends GeneCalc{
  public IncompleteDominance(ArrayList<String> x, ArrayList<String> y) {
    super(x, y);
  }

  public void phenotypeRatioCalc() {
    System.out.println("The code for phenotypic ratio has yet to be made");
  }
}