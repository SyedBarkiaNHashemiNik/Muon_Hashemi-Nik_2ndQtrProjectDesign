import java.util.*;

public class Codominance extends GeneCalc{
  public Codominance(ArrayList<String> x, ArrayList<String> y) {
    super(x, y);
  }

  public void phenotypeRatioCalc() {
    System.out.println("The code for phenotyic ratio has yet to be made");
  }
}