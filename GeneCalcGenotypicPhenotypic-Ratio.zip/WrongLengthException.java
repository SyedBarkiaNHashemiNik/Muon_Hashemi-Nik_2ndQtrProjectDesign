public class WrongLengthException extends Exception {
  public WrongLengthException (String wrongLengthMsg) {
    super(wrongLengthMsg);
  }
}